package com.breadwinner.wavebuddy

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import kotlin.math.sqrt

/**
 * Learns how YOUR voice comes out as text. Each time you teach a phrase, the odd way it was heard
 * ("open what sap") is remembered as meaning the real thing ("open whatsapp").
 */
object Learn {
    val items = mutableStateListOf<Pair<String, String>>()   // heard -> meant
    val wakes = mutableStateListOf<String>()                 // other ways your wake word was heard
    val misses = mutableStateListOf<String>()                // things I did not understand

    var target by mutableStateOf("")
    var kind by mutableStateOf("cmd")                        // cmd | wake
    var count by mutableStateOf(0)
    var msg by mutableStateOf("")
    var note by mutableStateOf("")
    val goal = 4

    val training: Boolean get() = Brain.mode == Brain.Mode.TRAIN

    fun load() {
        items.clear(); wakes.clear(); misses.clear()
        try {
            val a = JSONArray(Store.s("learned", "[]"))
            for (i in 0 until a.length()) {
                val p = a.getJSONArray(i)
                items.add(p.getString(0) to p.getString(1))
            }
        } catch (e: Exception) { }
        try {
            val a = JSONArray(Store.s("wakes", "[]"))
            for (i in 0 until a.length()) wakes.add(a.getString(i))
        } catch (e: Exception) { }
        try {
            val a = JSONArray(Store.s("misses", "[]"))
            for (i in 0 until a.length()) misses.add(a.getString(i))
        } catch (e: Exception) { }
        Voiceprint.load()
    }

    private fun saveItems() {
        val a = JSONArray()
        for ((h, m) in items) a.put(JSONArray().put(h).put(m))
        Store.put("learned", a.toString())
    }

    private fun saveWakes() {
        val a = JSONArray()
        for (w in wakes) a.put(w)
        Store.put("wakes", a.toString())
    }

    private fun saveMisses() {
        val a = JSONArray()
        for (w in misses) a.put(w)
        Store.put("misses", a.toString())
    }

    fun add(heard: String, meant: String) {
        if (heard.isBlank() || meant.isBlank() || heard == meant) return
        items.removeAll { it.first == heard }
        items.add(heard to meant)
        saveItems()
    }

    fun forget(p: Pair<String, String>) {
        items.remove(p)
        saveItems()
    }

    fun forgetWake(w: String) {
        wakes.remove(w)
        saveWakes()
    }

    fun miss(t: String) {
        if (t.length < 3) return
        if (misses.contains(t) || items.any { it.first == t }) return
        misses.add(0, t)
        while (misses.size > 25) misses.removeAt(misses.size - 1)
        saveMisses()
    }

    fun dismiss(t: String) {
        misses.remove(t)
        saveMisses()
    }

    /** Swaps in what you taught me, before the sentence is understood. */
    fun fix(t: String): String {
        if (items.isEmpty()) return t
        for ((h, m) in items) if (h == t) return m
        var best: Pair<String, String>? = null
        val padded = " $t "
        for (p in items) {
            if (p.first.length >= 4 && padded.contains(" " + p.first + " ")) {
                val b = best
                if (b == null || p.first.length > b.first.length) best = p
            }
        }
        val b = best ?: return t
        return padded.replace(" " + b.first + " ", " " + b.second + " ").trim()
    }

    fun suggestions(): List<String> {
        val l = ArrayList<String>()
        for (c in Store.cmds) if (c.enabled && !c.phrase.contains("{")) l.add(c.phrase)
        l.addAll(listOf("open whatsapp", "open chrome", "open camera", "go back", "go home", "scroll down", "scroll up", "flashlight on", "take a screenshot", "show recents"))
        return l.distinct().take(14)
    }

    // ---- teaching by saying it a few times

    fun start(what: String, k: String) {
        if (what.isBlank()) return
        target = what
        kind = k
        count = 0
        msg = "Say it now."
        note = ""
        Brain.switchMode(Brain.Mode.TRAIN)
        MicService.active(true)
        Fx.state(RingState.LISTEN)
    }

    fun stop() {
        if (Brain.mode == Brain.Mode.TRAIN) Brain.switchMode(Brain.Mode.IDLE)
        MicService.refreshGate()
        Fx.state(RingState.IDLE)
    }

    fun sample(raw: String) {
        val t = Norm.clean(raw)
        if (t.length < 3) return
        val tg = Norm.clean(target)
        if (tg.isEmpty()) return
        val close = Norm.sim(t, tg)
        if (t == tg) {
            msg = "I heard that one perfectly."
        } else if (close < 0.3f || t.split(" ").size > tg.split(" ").size + 3) {
            msg = "That sounded different. Say it again: \"" + tg + "\""
            return
        } else if (kind == "wake") {
            if (!wakes.contains(t)) { wakes.add(t); saveWakes() }
            msg = "Learned. I heard \"" + t + "\""
        } else {
            add(t, tg)
            msg = "Learned. I heard \"" + t + "\""
        }
        count++
        if (count >= goal) {
            note = "Done. I'll understand \"" + tg + "\" better now."
            stop()
        }
    }
}

/** Your voice-print: tells your voice from everyone else's, all on the phone. */
object Voiceprint {
    var enrolling by mutableStateOf(false)
    var count by mutableStateOf(0)
    var msg by mutableStateOf("")
    var lastDist by mutableStateOf(-1f)
    var lastOk by mutableStateOf(true)
    var blocked by mutableStateOf(0)
    var passed by mutableStateOf(0)
    var modelPresent by mutableStateOf(false)
    var enrolled by mutableStateOf(false)
    val goal = 8

    private val samples = ArrayList<FloatArray>()
    private var print: FloatArray? = null

    val prompts = listOf(
        "hey buddy, open whatsapp",
        "hey buddy, go back to the home screen",
        "scroll down a little bit please",
        "take a screenshot of this screen",
        "call mum on speaker",
        "turn on the flashlight for me",
        "set a timer for five minutes",
        "what is on the screen right now",
        "open my messages and read them",
        "hey buddy, lock the phone"
    )
    val prompt: String get() = prompts[count % prompts.size]

    fun load() {
        val s = Store.s("vp", "")
        val l = s.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (l.size >= 16) {
            print = l.toFloatArray()
            enrolled = true
        } else {
            print = null
            enrolled = false
        }
    }

    private fun unit(a: FloatArray): FloatArray {
        var s = 0f
        for (x in a) s += x * x
        val n = sqrt(s)
        if (n <= 0f) return a
        return FloatArray(a.size) { a[it] / n }
    }

    private fun dist(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 1f
        var d = 0f
        for (i in a.indices) d += a[i] * b[i]
        return 1f - d
    }

    fun lockOn(): Boolean = enrolled && Store.b("lockon", false)

    fun threshold(secs: Float): Float {
        val base = Store.f("vp_base", 0.5f)
        val mult = when (Store.s("strict", "normal")) {
            "loose" -> 1.25f
            "strict" -> 0.85f
            else -> 1f
        }
        return base * mult + (if (secs < 1.2f) 0.08f else 0f)
    }

    fun start() {
        samples.clear()
        count = 0
        msg = ""
        enrolling = true
        MicService.active(true)
    }

    fun cancel() {
        enrolling = false
        samples.clear()
        MicService.refreshGate()
    }

    fun clear() {
        print = null
        enrolled = false
        Store.put("vp", "")
        Store.put("lockon", false)
        lastDist = -1f
        blocked = 0
        passed = 0
    }

    /** While recording your voice: take this sentence as a sample and keep it away from the commands. */
    fun consume(a: FloatArray?, secs: Float): Boolean {
        if (!enrolling) return false
        if (a == null) {
            msg = "I couldn't take a voice-print from that. Try again a little louder."
            return true
        }
        if (secs < 1.0f) {
            msg = "A little longer, please. Say the whole line."
            return true
        }
        samples.add(unit(a))
        count = samples.size
        msg = "Got it."
        if (count >= goal) finish()
        return true
    }

    private fun finish() {
        val n = samples[0].size
        val sum = FloatArray(n)
        for (s in samples) for (i in 0 until n) sum[i] += s[i]
        val mean = unit(sum)
        var worst = 0f
        for (s in samples) worst = maxOf(worst, dist(s, mean))
        val base = (worst + 0.12f).coerceIn(0.35f, 0.8f)
        Store.put("vp", mean.joinToString(","))
        Store.put("vp_base", base)
        Store.put("lockon", true)
        print = mean
        enrolled = true
        enrolling = false
        samples.clear()
        blocked = 0
        passed = 0
        msg = "Saved. I'll only obey your voice now."
        MicService.refreshGate()
    }

    /** True if this sentence should be obeyed. Also keeps the "last match" numbers up to date. */
    fun allows(a: FloatArray?, secs: Float): Boolean {
        val p = print ?: return true
        if (a == null) return true
        val d = dist(unit(a), p)
        val ok = d <= threshold(secs)
        lastDist = d
        lastOk = ok
        if (!Store.b("lockon", false)) return true
        if (Brain.forced || Learn.training) return true
        if (ok) passed++ else blocked++
        return ok
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TrainPage(back: () -> Unit) {
    var target by remember { mutableStateOf("") }
    var fixing by remember { mutableStateOf("") }
    var meant by remember { mutableStateOf("") }
    Page {
        Header("Train me", "Teach me how you really sound", back)

        Glass {
            Tx("Teach a command", 16)
            Tx("Pick or type what it should be, then say it " + Learn.goal + " times. I remember how I hear you.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            if (Learn.training) {
                Tx("Say: \"" + Learn.target + "\"", 20)
                Tx(Learn.count.toString() + " of " + Learn.goal, 15, Coral)
                if (Buddy.heard.isNotEmpty()) Tx("I heard: \"" + Buddy.heard + "\"", 12, Mute, FontWeight.Normal)
                if (Learn.msg.isNotEmpty()) Tx(Learn.msg, 13, Good)
                Spacer(Modifier.height(8.dp))
                Btn("Stop") { Learn.stop() }
            } else {
                TextBox(target, "e.g. open whatsapp") { target = it }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (s in Learn.suggestions()) Chip(s, s == target) { target = s }
                }
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("Start teaching", filled = true, enabled = target.isNotBlank() && Buddy.micOn) {
                        Learn.start(Norm.clean(target), "cmd")
                    }
                }
                if (!Buddy.micOn) Tx("Tap Start listening on the home page first.", 12, Bad, FontWeight.Normal)
                if (Learn.note.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Tx(Learn.note, 13, Good)
                }
            }
        }

        Glass {
            Tx("Didn't understand", 16)
            Tx("When I can't match what you said, it lands here. Tap Fix and tell me what you meant.", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            if (Learn.misses.isEmpty()) Tx("Nothing yet.", 13, Mute, FontWeight.Normal)
            for (m in Learn.misses.toList()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("\"" + m + "\"", 14, modifier = Modifier.weight(1f))
                    Btn("Fix", filled = fixing == m) { fixing = m; meant = "" }
                    Spacer(Modifier.width(6.dp))
                    Btn("✕") { Learn.dismiss(m); if (fixing == m) fixing = "" }
                }
            }
            if (fixing.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Tx("What did you mean by \"" + fixing + "\"?", 13)
                Spacer(Modifier.height(6.dp))
                TextBox(meant, "e.g. open whatsapp") { meant = it }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (s in Learn.suggestions()) Chip(s, s == meant) { meant = s }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Btn("Save", filled = true, enabled = meant.isNotBlank()) {
                        Learn.add(fixing, Norm.clean(meant))
                        Learn.dismiss(fixing)
                        fixing = ""
                        meant = ""
                    }
                    Btn("Cancel") { fixing = ""; meant = "" }
                }
            }
        }

        Glass {
            Tx("What I've learned", 16)
            Spacer(Modifier.height(4.dp))
            if (Learn.items.isEmpty() && Learn.wakes.isEmpty()) Tx("Nothing yet.", 13, Mute, FontWeight.Normal)
            for (p in Learn.items.toList()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("\"" + p.first + "\" → " + p.second, 13, modifier = Modifier.weight(1f))
                    Btn("✕") { Learn.forget(p) }
                }
            }
            for (w in Learn.wakes.toList()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tx("Wake word: \"" + w + "\"", 13, modifier = Modifier.weight(1f))
                    Btn("✕") { Learn.forgetWake(w) }
                }
            }
        }
    }
}

@Composable
fun VoiceLockPage(back: () -> Unit) {
    Page {
        Header("Only my voice", "I'll ignore everyone else", back)

        Glass {
            if (!Voiceprint.modelPresent) {
                Tx("The voice-print file isn't in this build, so this can't work yet. Start listening on the home page first, then come back. If it still says this, tell me.", 12, Bad, FontWeight.Normal)
                Spacer(Modifier.height(8.dp))
            }
            ToggleRow(
                "Only obey my voice",
                if (Voiceprint.enrolled) "Other people, the TV and speakers get ignored." else "Record your voice first.",
                Store.b("lockon", false) && Voiceprint.enrolled
            ) { if (Voiceprint.enrolled) Store.put("lockon", it) }
        }

        Glass {
            Tx("Your voice", 16)
            Spacer(Modifier.height(6.dp))
            EnrollBlock()
        }

        Glass {
            Tx("How strict", 16)
            Spacer(Modifier.height(6.dp))
            val modes = listOf("loose", "normal", "strict")
            Seg(listOf("Loose", "Normal", "Strict"), modes.indexOf(Store.s("strict", "normal")).coerceAtLeast(0)) { Store.put("strict", modes[it]) }
            Tx("Loose lets more through, Strict ignores more. If I ever ignore you, slide to Loose.", 12, Mute, FontWeight.Normal)
        }

        Glass {
            Tx("Live check", 16)
            Spacer(Modifier.height(4.dp))
            if (Voiceprint.lastDist < 0f) {
                Tx("Say something and I'll show how well it matched your voice.", 13, Mute, FontWeight.Normal)
            } else {
                val need = Voiceprint.threshold(2f)
                Tx(
                    (if (Voiceprint.lastOk) "✓ Sounded like you" else "✕ Didn't sound like you") +
                        "   match " + "%.2f".format(java.util.Locale.US, Voiceprint.lastDist) +
                        " (needs under " + "%.2f".format(java.util.Locale.US, need) + ")",
                    13, if (Voiceprint.lastOk) Good else Bad
                )
                Tx("Obeyed " + Voiceprint.passed + ", ignored " + Voiceprint.blocked, 12, Mute, FontWeight.Normal)
            }
            Spacer(Modifier.height(8.dp))
            Tx("Holding the round button always works, even if I'm ignoring you. This stops casual voices, it isn't a security lock. Very short words give me less to go on, so I'm a bit easier on those.", 12, Mute, FontWeight.Normal)
        }
    }
}

/** Recording the 8 lines for your voice-print. Used on the Only my voice page and in Setup. */
@Composable
fun EnrollBlock() {
        if (Voiceprint.enrolling) {
            Tx("Say this out loud:", 13, Mute, FontWeight.Normal)
            Tx("\"" + Voiceprint.prompt + "\"", 20)
            Tx(Voiceprint.count.toString() + " of " + Voiceprint.goal, 15, Coral)
            if (Voiceprint.msg.isNotEmpty()) Tx(Voiceprint.msg, 13, Good)
            if (Buddy.heard.isNotEmpty()) Tx("I heard: \"" + Buddy.heard + "\"", 12, Mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            Btn("Cancel") { Voiceprint.cancel() }
        } else {
            Tx(
                if (Voiceprint.enrolled) "Your voice is saved." else "I'll ask you to say " + Voiceprint.goal + " short lines. Do it in your normal voice, somewhere fairly quiet.",
                13, Mute, FontWeight.Normal
            )
            if (Voiceprint.msg.isNotEmpty()) Tx(Voiceprint.msg, 13, Good)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn(if (Voiceprint.enrolled) "Record again" else "Record my voice", filled = true, enabled = Buddy.micOn && Voiceprint.modelPresent) {
                    Voiceprint.start()
                }
                if (Voiceprint.enrolled) Btn("Forget my voice") { Voiceprint.clear() }
            }
            if (!Buddy.micOn) Tx("Tap Start listening on the home page first.", 12, Bad, FontWeight.Normal)
        }
}
