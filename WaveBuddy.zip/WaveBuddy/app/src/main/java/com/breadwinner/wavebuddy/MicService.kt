package com.breadwinner.wavebuddy

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream

/** Keeps the microphone open and turns speech into words, all on the phone. */
class MicService : Service() {
    companion object {
        @Volatile var inst: MicService? = null

        fun hasMic(c: Context) =
            ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        fun start(c: Context) {
            if (!hasMic(c)) return
            try {
                ContextCompat.startForegroundService(c, Intent(c, MicService::class.java))
            } catch (e: Exception) {
                Buddy.status = "Android wouldn't start the listener. Open WaveBuddy and tap Start."
            }
        }

        fun stop() {
            val s = inst
            if (s != null) s.shutdown()
        }

        fun refreshGate() {
            Handler(Looper.getMainLooper()).post { inst?.applyGate() }
        }

        fun active(on: Boolean) {
            Handler(Looper.getMainLooper()).post { if (on) inst?.speech?.setPause(false) else inst?.applyGate() }
        }
    }

    var speech: SpeechService? = null
    private var model: Model? = null
    private var spkModel: SpeakerModel? = null
    private var rec: Recognizer? = null
    private var starting = false
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        inst = this
        showNote()
        if (!hasMic(this)) {
            Buddy.status = "Needs the microphone permission."
            stopSelf()
            return START_NOT_STICKY
        }
        if (speech == null && !starting) {
            starting = true
            Buddy.status = "Getting ready..."
            Thread { boot() }.start()
        }
        Store.put("listening", true)
        return START_STICKY
    }

    private fun showNote() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel("listen") == null) {
            nm.createNotificationChannel(NotificationChannel("listen", "WaveBuddy is listening", NotificationManager.IMPORTANCE_LOW))
        }
        fun act(a: String, label: String): NotificationCompat.Action {
            val pi = PendingIntent.getBroadcast(
                this, a.hashCode(), Intent(this, ActionReceiver::class.java).setAction(a),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return NotificationCompat.Action(0, label, pi)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, "listen")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveBuddy is here")
            .setContentText("Say \"" + Store.wake + "\". Everything stays on your phone.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(act("pause", "Sleep"))
            .addAction(act("resume", "Wake"))
            .addAction(act("stop", "Stop"))
            .build()
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: return
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dest, n))
        }
    }

    private fun boot() {
        try {
            val dir = File(filesDir, "voice-model")
            val mark = File(dir, ".done")
            if (!mark.exists()) {
                val have = try { assets.list("model")?.isNotEmpty() == true } catch (e: Exception) { false }
                if (!have) {
                    Buddy.modelError = "The voice model is missing from this build."
                    Buddy.status = Buddy.modelError
                    starting = false
                    return
                }
                Buddy.status = "Unpacking the voice model (first time only)..."
                dir.deleteRecursively()
                copyAssets("model", dir)
                mark.writeText("ok")
            }
            Buddy.status = "Loading the voice model..."
            val m = Model(dir.absolutePath)
            model = m
            var sm: SpeakerModel? = null
            try {
                val sdir = File(filesDir, "spk-model")
                val smark = File(sdir, ".done")
                if (!smark.exists() && (assets.list("spk")?.isNotEmpty() == true)) {
                    sdir.deleteRecursively()
                    copyAssets("spk", sdir)
                    smark.writeText("ok")
                }
                if (smark.exists()) sm = SpeakerModel(sdir.absolutePath)
            } catch (e: Throwable) {
                sm = null
            }
            val smf: SpeakerModel? = sm
            spkModel = smf
            Voiceprint.modelPresent = smf != null
            val r = if (smf != null) Recognizer(m, 16000.0f, smf) else Recognizer(m, 16000.0f)
            rec = r
            val s = SpeechService(r, 16000.0f)
            speech = s
            s.startListening(object : RecognitionListener {
                override fun onPartialResult(h: String?) {
                    if (h == null) return
                    val t = try { JSONObject(h).optString("partial") } catch (e: Exception) { "" }
                    if (t.isNotBlank()) Brain.onPartial(t)
                }

                override fun onResult(h: String?) {
                    deliver(h)
                }

                override fun onFinalResult(h: String?) {
                    deliver(h)
                }

                override fun onError(e: Exception?) {
                    Buddy.status = "Microphone problem: " + (e?.message ?: "unknown")
                }

                override fun onTimeout() {}
            })
            Buddy.modelReady = true
            Buddy.modelError = ""
            Buddy.micOn = true
            main.post { applyGate() }
        } catch (e: Throwable) {
            Buddy.modelError = "Couldn't start listening: " + (e.message ?: e.javaClass.simpleName)
            Buddy.status = Buddy.modelError
        }
        starting = false
    }

    /** A finished sentence: first the voice check, then on to the brain. */
    private fun deliver(h: String?) {
        if (h == null) return
        val o = try { JSONObject(h) } catch (e: Exception) { return }
        val t = o.optString("text")
        if (t.isBlank()) return
        val v = o.optJSONArray("spk")
        val frames = o.optInt("spk_frames", 0)
        if (Voiceprint.consume(v, frames)) return
        if (!Voiceprint.allows(v, frames)) return
        Brain.onFinal(t)
    }

    fun applyGate() {
        val s = speech ?: return
        val gate = !Buddy.sleeping && (Store.b("wakeon", true) || Brain.forced)
        try { s.setPause(!gate) } catch (e: Exception) { }
        Buddy.status = when {
            Buddy.sleeping -> "Sleeping. Tap the round button to wake me."
            Store.b("wakeon", true) -> "Listening for \"" + Store.wake + "\""
            else -> "Ready. Hold the round button and speak."
        }
    }

    fun shutdown() {
        try { speech?.stop(); speech?.shutdown() } catch (e: Exception) { }
        try { rec?.close() } catch (e: Exception) { }
        try { model?.close() } catch (e: Exception) { }
        try { spkModel?.close() } catch (e: Exception) { }
        speech = null
        rec = null
        model = null
        spkModel = null
        Buddy.micOn = false
        Buddy.modelReady = false
        Buddy.status = "Not listening"
        Store.put("listening", false)
        inst = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (inst === this) {
            try { speech?.shutdown() } catch (e: Exception) { }
            Buddy.micOn = false
            inst = null
        }
        super.onDestroy()
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        when (intent.action) {
            "pause" -> { Buddy.sleeping = true; MicService.refreshGate(); Hands.inst?.setFabMode() }
            "resume" -> { Buddy.sleeping = false; MicService.refreshGate(); Hands.inst?.setFabMode() }
            "stop" -> MicService.stop()
        }
    }
}
