package com.breadwinner.wavebuddy

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Keeps the microphone open in the background and runs the ears, all on the phone. */
class MicService : Service() {
    companion object {
        @Volatile var inst: MicService? = null

        fun hasMic(c: Context) =
            ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        fun start(c: Context) {
            if (!hasMic(c)) return
            try {
                ContextCompat.startForegroundService(c, Intent(c, MicService::class.java))
            } catch (e: Exception) {
                Buddy.status = "Android wouldn't start the listener. Open WaveBuddy and tap Start."
            }
        }

        fun stop() {
            val s = inst
            if (s != null) s.shutdown()
        }

        fun refreshGate() {
            Handler(Looper.getMainLooper()).post { inst?.applyGate() }
        }

        /** The ears are always open while running; this only refreshes what the screen says. */
        fun active(on: Boolean) {
            refreshGate()
        }
    }

    private var starting = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        inst = this
        showNote()
        if (!hasMic(this)) {
            Buddy.status = "Needs the microphone permission."
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Ear.running && !starting) {
            starting = true
            Buddy.status = "Waking up..."
            Thread { boot() }.start()
        }
        Store.put("listening", true)
        return START_STICKY
    }

    private fun showNote() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel("listen") == null) {
            nm.createNotificationChannel(NotificationChannel("listen", "WaveBuddy is listening", NotificationManager.IMPORTANCE_LOW))
        }
        fun act(a: String, label: String): NotificationCompat.Action {
            val pi = PendingIntent.getBroadcast(
                this, a.hashCode(), Intent(this, ActionReceiver::class.java).setAction(a),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return NotificationCompat.Action(0, label, pi)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, "listen")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveBuddy is here")
            .setContentText("Say \"" + Store.wake + "\". Everything stays on your phone.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(act("pause", "Sleep"))
            .addAction(act("resume", "Wake"))
            .addAction(act("stop", "Stop"))
            .build()
        if (android.os.Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun boot() {
        if (!Ear.ready) Buddy.status = "Loading the speech engine (a few seconds)..."
        val err = Ear.load(applicationContext)
        if (err != null) {
            Buddy.modelError = err
            Buddy.status = err
            starting = false
            return
        }
        Ear.start()
        Buddy.modelReady = true
        Buddy.modelError = ""
        Buddy.micOn = true
        starting = false
        Handler(Looper.getMainLooper()).post { applyGate() }
    }

    fun applyGate() {
        if (!Ear.running) return
        Buddy.status = when {
            Buddy.sleeping -> "Sleeping. Tap the round button to wake me."
            Store.b("wakeon", true) && Ear.hasWake -> "Listening for \"" + Store.wake + "\""
            Store.b("wakeon", true) -> "Listening (wake word engine missing, so I'm hearing everything)"
            else -> "Ready. Hold the round button and speak."
        }
    }

    fun shutdown() {
        Ear.stop()
        Buddy.micOn = false
        Buddy.status = "Not listening"
        Store.put("listening", false)
        inst = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (inst === this) {
            Ear.stop()
            Buddy.micOn = false
            inst = null
        }
        super.onDestroy()
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        when (intent.action) {
            "pause" -> { Buddy.sleeping = true; MicService.refreshGate(); Hands.inst?.setFabMode() }
            "resume" -> { Buddy.sleeping = false; MicService.refreshGate(); Hands.inst?.setFabMode() }
            "stop" -> MicService.stop()
        }
    }
}
