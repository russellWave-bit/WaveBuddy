package com.breadwinner.wavebuddy

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject

/** One thing WaveBuddy can do. Built-in words and your own recorded commands are made of these. */
data class Step(val type: String, val a: String = "", val b: String = "", val n: Int = 0)

data class Command(
    val id: String,
    val phrase: String,
    val steps: List<Step>,
    val enabled: Boolean = true,
    val ask: Boolean = false
)

/** Every setting lives in one observable map, so screens update the moment something changes. */
object Store {
    private var sp: SharedPreferences? = null
    lateinit var app: Context
    val m = mutableStateMapOf<String, String>()
    val cmds = mutableStateListOf<Command>()
    val vocab = mutableStateListOf<Pair<String, String>>()

    fun init(c: Context) {
        if (sp != null) return
        app = c.applicationContext
        val p = app.getSharedPreferences("wavebuddy", 0)
        sp = p
        for ((k, v) in p.all) if (v is String && k != "cmds" && k != "vocab") m[k] = v
        loadCmds(p.getString("cmds", null))
        loadVocab(p.getString("vocab", null))
        Learn.load()
        if (!b("seeded1", false)) {
            cmds.addAll(Starter.pack())
            put("seeded1", true)
            saveCmds()
        }
    }

    fun s(k: String, d: String): String = m[k] ?: d
    fun i(k: String, d: Int): Int = m[k]?.toIntOrNull() ?: d
    fun f(k: String, d: Float): Float = m[k]?.toFloatOrNull() ?: d
    fun b(k: String, d: Boolean): Boolean = m[k]?.let { it == "1" } ?: d

    fun put(k: String, v: Any) {
        val str = when (v) {
            is Boolean -> if (v) "1" else "0"
            else -> v.toString()
        }
        m[k] = str
        sp?.edit()?.putString(k, str)?.apply()
    }

    // ---- the settings, with their defaults
    val wake get() = s("wake", "hey buddy")
    val listening get() = b("listening", false)
    val confirm get() = s("confirm", "risky")           // risky | always | never
    val secret get() = s("secret", "")
    val stayAwake get() = i("stay", 10)                  // seconds after a command, still listening
    val speak get() = b("speak", false)
    val cues get() = b("cues", true)
    val country get() = s("country", "263")
    val style get() = s("style", "drop")                 // float | drop | fade
    val textSize get() = i("tsize", 56)
    val holdMs get() = i("hold", 1500)
    val posY get() = f("posy", 0.45f)
    val font get() = s("font", "rounded")
    val textColor get() = s("tcolor", "cream")
    val theme get() = s("theme", "lamp")
    val ringOn get() = b("ring", true)
    val ringIdle get() = b("ringidle", true)
    val edgeGlow get() = b("edge", false)
    val ringThick get() = f("rthick", 5f)
    val ringGlow get() = f("rglow", 0.7f)
    val ringSpeed get() = f("rspeed", 1f)
    val ringX get() = f("rx", 0.5f)
    val ringY get() = f("ry", 0.021f)
    val ringR get() = f("rr", 0.024f)
    val fabOn get() = b("fab", true)
    val fabX get() = f("fabx", 0.86f)
    val fabY get() = f("faby", 0.62f)
    fun power(k: String) = b("p_$k", true)

    // ---- commands
    fun saveCmds() {
        val arr = JSONArray()
        for (c in cmds) {
            val o = JSONObject().put("id", c.id).put("phrase", c.phrase).put("on", c.enabled).put("ask", c.ask)
            val st = JSONArray()
            for (s in c.steps) st.put(JSONObject().put("t", s.type).put("a", s.a).put("b", s.b).put("n", s.n))
            o.put("steps", st)
            arr.put(o)
        }
        sp?.edit()?.putString("cmds", arr.toString())?.apply()
    }

    private fun loadCmds(js: String?) {
        cmds.clear()
        if (js == null) return
        try {
            val arr = JSONArray(js)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val st = ArrayList<Step>()
                val sa = o.getJSONArray("steps")
                for (j in 0 until sa.length()) {
                    val so = sa.getJSONObject(j)
                    st.add(Step(so.optString("t"), so.optString("a"), so.optString("b"), so.optInt("n")))
                }
                cmds.add(Command(o.optString("id"), o.optString("phrase"), st, o.optBoolean("on", true), o.optBoolean("ask", false)))
            }
        } catch (e: Exception) {
        }
    }

    fun saveVocab() {
        val arr = JSONArray()
        for ((a, b) in vocab) arr.put(JSONArray().put(a).put(b))
        sp?.edit()?.putString("vocab", arr.toString())?.apply()
    }

    private fun loadVocab(js: String?) {
        vocab.clear()
        if (js == null) return
        try {
            val arr = JSONArray(js)
            for (i in 0 until arr.length()) {
                val p = arr.getJSONArray(i)
                vocab.add(p.getString(0) to p.getString(1))
            }
        } catch (e: Exception) {
        }
    }

    fun newId(): String = System.currentTimeMillis().toString() + (Math.random() * 1000).toInt()
}

/** The commands that come in the box. All of them can be edited, switched off or deleted. */
object Starter {
    fun pack(): List<Command> = listOf(
        Command(Store.newId() + "a", "whatsapp call {name}", listOf(
            Step("WA_CHAT", "{name}"), Step("WAIT", n = 1600), Step("TAP_TEXT", "Voice call|Audio call|Call")
        ), true, true),
        Command(Store.newId() + "b", "whatsapp video call {name}", listOf(
            Step("WA_CHAT", "{name}"), Step("WAIT", n = 1600), Step("TAP_TEXT", "Video call")
        ), true, true),
        Command(Store.newId() + "c", "whatsapp message {name} {text}", listOf(
            Step("WA_CHAT", "{name}"), Step("WAIT", n = 1600), Step("TYPE", "{text}"), Step("WAIT", n = 300), Step("SEND")
        ), true, true),
        Command(Store.newId() + "d", "whatsapp open {name}", listOf(Step("WA_CHAT", "{name}"))),
        Command(Store.newId() + "e", "facebook open marketplace", listOf(
            Step("OPEN_APP", "facebook"), Step("WAIT", n = 1800), Step("TAP_TEXT", "Marketplace")
        )),
        Command(Store.newId() + "f", "youtube search {text}", listOf(
            Step("OPEN_APP", "youtube"), Step("WAIT", n = 1800), Step("TAP_TEXT", "Search"), Step("WAIT", n = 600),
            Step("TYPE", "{text}"), Step("WAIT", n = 300), Step("SEND")
        )),
        Command(Store.newId() + "g", "take a photo", listOf(
            Step("OPEN_APP", "camera"), Step("WAIT", n = 1400), Step("TAP_TEXT", "Shutter|Take picture|Capture")
        ))
    )
}
