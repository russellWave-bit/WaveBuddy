package com.breadwinner.wavebuddy

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.KeywordSpotter
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractor
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractorConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import java.util.concurrent.Executors

/**
 * The ears. Four small engines, all on the phone:
 *  - a wake-word spotter that only listens for "hey buddy"
 *  - a voice detector that cuts the sound into sentences
 *  - Parakeet, which turns a sentence into words
 *  - a voice-print engine, for "Only my voice"
 */
object Ear {
    private const val RATE = 16000
    private const val KWS_DIR = "kws"
    private const val KWS_ENC = "encoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx"
    private const val KWS_DEC = "decoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx"
    private const val KWS_JOIN = "joiner-epoch-12-avg-2-chunk-16-left-64.int8.onnx"

    @Volatile private var kws: KeywordSpotter? = null
    @Volatile private var kwsStream: OnlineStream? = null
    @Volatile private var vad: Vad? = null
    @Volatile private var asr: OfflineRecognizer? = null
    @Volatile private var spk: SpeakerEmbeddingExtractor? = null

    @Volatile var running = false
    @Volatile private var gen = 0
    @Volatile private var wakeUntil = 0L
    @Volatile private var kwsDirty = false
    private var thread: Thread? = null
    private val work = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    // the last two seconds of sound, for checking the voice on a wake word
    private val ring = FloatArray(RATE * 2)
    private var ringPos = 0
    private var ringFull = false

    val ready: Boolean get() = asr != null && vad != null
    val hasVoicePrint: Boolean get() = spk != null
    val hasWake: Boolean get() = kws != null

    private fun exists(am: AssetManager, path: String): Boolean =
        try { am.open(path).close(); true } catch (e: Exception) { false }

    /** Loads the engines. Slow the first time (a few seconds), so call it off the main thread. */
    fun load(c: Context): String? {
        val am = c.assets
        try {
            if (vad == null) {
                if (!exists(am, "silero_vad.onnx")) return "The voice detector is missing from this build."
                vad = Vad(
                    am, VadModelConfig(
                        sileroVadModelConfig = SileroVadModelConfig(
                            model = "silero_vad.onnx",
                            threshold = 0.5f,
                            minSilenceDuration = 0.6f,
                            minSpeechDuration = 0.2f,
                            windowSize = 512,
                            maxSpeechDuration = 14f,
                        ),
                        sampleRate = RATE,
                        numThreads = 1,
                    )
                )
            }
            if (spk == null && exists(am, "speaker.onnx")) {
                try {
                    spk = SpeakerEmbeddingExtractor(am, SpeakerEmbeddingExtractorConfig(model = "speaker.onnx", numThreads = 2))
                } catch (e: Throwable) {
                    spk = null
                }
            }
            Voiceprint.modelPresent = spk != null
            if (kws == null) buildKws(am)
            if (asr == null) {
                if (!exists(am, "asr/encoder.int8.onnx")) return "The speech engine is missing from this build."
                Buddy.status = "Loading the speech engine..."
                asr = OfflineRecognizer(
                    am, OfflineRecognizerConfig(
                        featConfig = FeatureConfig(sampleRate = RATE, featureDim = 80),
                        modelConfig = OfflineModelConfig(
                            transducer = OfflineTransducerModelConfig(
                                encoder = "asr/encoder.int8.onnx",
                                decoder = "asr/decoder.int8.onnx",
                                joiner = "asr/joiner.int8.onnx",
                            ),
                            tokens = "asr/tokens.txt",
                            modelType = "nemo_transducer",
                            numThreads = 4,
                        ),
                    )
                )
            }
        } catch (e: Throwable) {
            return "Couldn't start the engines: " + (e.message ?: e.javaClass.simpleName)
        }
        return null
    }

    private fun buildKws(am: AssetManager) {
        if (!exists(am, "$KWS_DIR/$KWS_ENC")) { kws = null; return }
        try {
            val k = KeywordSpotter(
                am, KeywordSpotterConfig(
                    featConfig = FeatureConfig(sampleRate = RATE, featureDim = 80),
                    modelConfig = OnlineModelConfig(
                        transducer = OnlineTransducerModelConfig(
                            encoder = "$KWS_DIR/$KWS_ENC",
                            decoder = "$KWS_DIR/$KWS_DEC",
                            joiner = "$KWS_DIR/$KWS_JOIN",
                        ),
                        tokens = "$KWS_DIR/tokens.txt",
                        modelType = "zipformer2",
                        numThreads = 1,
                    ),
                    keywordsFile = "$KWS_DIR/keywords.txt",
                    keywordsScore = 1.8f,
                    keywordsThreshold = wakeThreshold(),
                )
            )
            kws = k
            kwsStream = k.createStream(extraKeywords())
        } catch (e: Throwable) {
            kws = null
            kwsStream = null
        }
    }

    /** Lower means it wakes more easily. The Wake sensitivity slider sets this. */
    private fun wakeThreshold(): Float = when (Store.s("wakesens", "normal")) {
        "easy" -> 0.12f
        "strict" -> 0.32f
        else -> 0.2f
    }

    private fun extraKeywords(): String =
        if (Norm.clean(Store.wake) == "buddy") "▁BU D D Y :1.5 @BUDDY" else ""

    /** Call after the wake word or its sensitivity changes. */
    fun rebuildWake(c: Context) {
        kwsDirty = true
        Thread {
            val old = kws
            kws = null
            kwsStream = null
            try { old?.release() } catch (e: Throwable) { }
            buildKws(c.assets)
            kwsDirty = false
        }.start()
    }

    fun start() {
        if (running) return
        running = true
        gen++
        val g = gen
        thread = Thread { loop(g) }.also { it.priority = Thread.MAX_PRIORITY; it.start() }
    }

    fun stop() {
        running = false
        thread = null
    }

    private fun wantsWords(): Boolean =
        Brain.wantsFull() || System.currentTimeMillis() < wakeUntil || Learn.training || Voiceprint.enrolling || kws == null

    @SuppressLint("MissingPermission")
    private fun loop(g: Int) {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 6400) * 2
            )
        } catch (e: Throwable) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            Buddy.status = "Couldn't open the microphone. Is another app using it?"
            running = false
            return
        }
        rec.startRecording()
        val buf = ShortArray(512)
        var wasSpeaking = false
        try {
            while (running && g == gen) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                val s = FloatArray(n) { buf[it] / 32768f }
                remember(s)
                val awakeOk = !Buddy.sleeping || Brain.forced || Learn.training || Voiceprint.enrolling
                if (!awakeOk) { vad?.reset(); continue }

                // 1. the wake word
                val k = kws
                val ks = kwsStream
                if (k != null && ks != null && !kwsDirty && Store.b("wakeon", true)) {
                    ks.acceptWaveform(s, RATE)
                    while (k.isReady(ks)) {
                        k.decode(ks)
                        if (k.getResult(ks).keyword.isNotBlank()) {
                            k.reset(ks)
                            onWakeWord()
                        }
                    }
                }

                // 2. cut the sound into sentences
                val v = vad ?: continue
                v.acceptWaveform(s)
                val speaking = v.isSpeechDetected()
                if (speaking && !wasSpeaking && wantsWords()) main.post { Fx.state(RingState.HEAR) }
                wasSpeaking = speaking
                while (!v.empty()) {
                    val seg = v.front()
                    v.pop()
                    onSentence(seg.samples)
                }
            }
        } catch (e: Throwable) {
            Buddy.status = "The microphone stopped: " + (e.message ?: e.javaClass.simpleName)
        }
        try { rec.stop() } catch (e: Throwable) { }
        rec.release()
        if (g == gen) running = false
    }

    private fun remember(s: FloatArray) {
        for (x in s) {
            ring[ringPos] = x
            ringPos++
            if (ringPos >= ring.size) { ringPos = 0; ringFull = true }
        }
    }

    private fun lastSeconds(secs: Float): FloatArray {
        val want = minOf((secs * RATE).toInt(), if (ringFull) ring.size else ringPos)
        val out = FloatArray(want)
        var p = ringPos - want
        if (p < 0) p += ring.size
        for (i in 0 until want) {
            out[i] = ring[p]
            p++
            if (p >= ring.size) p = 0
        }
        return out
    }

    private fun onWakeWord() {
        if (Voiceprint.lockOn()) {
            val sample = lastSeconds(1.6f)
            val emb = embed(sample)
            if (!Voiceprint.allows(emb, sample.size / RATE.toFloat())) return
        }
        wakeUntil = System.currentTimeMillis() + 8000
        Brain.onWakeWord()
    }

    private fun onSentence(samples: FloatArray) {
        val secs = samples.size / RATE.toFloat()
        if (secs < 0.3f) return
        if (!wantsWords()) return
        val copy = samples.copyOf()
        work.execute { understand(copy, secs) }
    }

    private fun understand(samples: FloatArray, secs: Float) {
        val needVoice = spk != null && (Voiceprint.enrolling || Voiceprint.enrolled)
        val emb = if (needVoice) embed(samples) else null
        val text = transcribe(samples)
        if (Voiceprint.enrolling) {
            if (text.isNotBlank()) Buddy.heard = Norm.clean(text)
            Voiceprint.consume(emb, secs)
            return
        }
        if (text.isBlank()) return
        if (!Voiceprint.allows(emb, secs)) return
        Brain.onFinal(text)
    }

    private fun transcribe(samples: FloatArray): String {
        val r = asr ?: return ""
        return try {
            val st = r.createStream()
            st.acceptWaveform(samples, RATE)
            r.decode(st)
            val t = r.getResult(st).text
            st.release()
            t
        } catch (e: Throwable) {
            ""
        }
    }

    private fun embed(samples: FloatArray): FloatArray? {
        val x = spk ?: return null
        if (samples.size < RATE / 2) return null
        return try {
            val st = x.createStream()
            st.acceptWaveform(samples, RATE)
            st.inputFinished()
            val out = if (x.isReady(st)) x.compute(st) else null
            st.release()
            out
        } catch (e: Throwable) {
            null
        }
    }
}
