package com.breadwinner.wavebuddy

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// Warm and homey: cream and peach, with a coral, violet and sky glow.
val Cream = Color(0xFFFFF8F0)
val Peach = Color(0xFFF8E2D0)
val Ink = Color(0xFF3A2E2A)
val Mute = Color(0xFF8A766B)
val Coral = Color(0xFFE8785A)
val Violet = Color(0xFF8B7BE8)
val SkyBlue = Color(0xFF6FA8F5)
val Good = Color(0xFF4FA676)
val Bad = Color(0xFFD9534F)
val Hair = Color(0x2B3A2E2A)

@Composable
fun Tx(
    text: String, size: Int = 14, color: Color = Ink,
    weight: FontWeight = FontWeight.SemiBold, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

fun Modifier.sky(): Modifier = this
    .background(Brush.verticalGradient(listOf(Cream, Peach)))
    .drawBehind {
        drawCircle(
            Brush.radialGradient(listOf(Color(0x66FFB79A), Color.Transparent), Offset(size.width * 0.1f, size.height * 0.04f), size.width * 0.9f),
            size.width * 0.9f, Offset(size.width * 0.1f, size.height * 0.04f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0x55B9A6F5), Color.Transparent), Offset(size.width * 0.95f, size.height * 0.92f), size.width * 0.9f),
            size.width * 0.9f, Offset(size.width * 0.95f, size.height * 0.92f)
        )
    }

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(8.dp, shape, ambientColor = Color(0x33A0522D), spotColor = Color(0x33A0522D))
            .background(Brush.verticalGradient(listOf(Color(0xF2FFFFFF), Color(0xCCFFFFFF))), shape)
            .border(1.dp, Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0x80FFFFFF))), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val fill = if (filled) Brush.verticalGradient(listOf(Coral.copy(alpha = 0.92f), Coral))
    else Brush.verticalGradient(listOf(Color(0xFAFFFFFF), Color(0xD9FFFFFF)))
    Box(
        modifier
            .clip(shape)
            .background(fill, shape)
            .border(1.dp, if (filled) Color(0x33FFFFFF) else Hair, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Tx(text, 14, if (filled) Color.White else if (enabled) Ink else Mute)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (selected) Coral else Color(0x14000000), shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Tx(text, 13, if (selected) Color.White else Ink) }
}

@Composable
fun ToggleRow(title: String, sub: String = "", on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Tx(title, 14)
            if (sub.isNotEmpty()) Tx(sub, 12, Mute, FontWeight.Normal)
        }
        Switch(checked = on, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = Coral, checkedThumbColor = Color.White))
    }
}

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x14000000)).padding(3.dp)) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (i == sel) Color.White else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) { Tx(s, 12, if (i == sel) Coral else Mute) }
        }
    }
}

@Composable
fun TextBox(value: String, hint: String, modifier: Modifier = Modifier, numbers: Boolean = false, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.fillMaxWidth().clip(shape).background(Color(0xFAFFFDFB), shape).border(1.dp, Hair, shape)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        if (value.isEmpty()) Tx(hint, 14, Mute, FontWeight.Normal)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 15.sp),
            cursorBrush = SolidColor(Coral),
            keyboardOptions = KeyboardOptions(keyboardType = if (numbers) KeyboardType.Number else KeyboardType.Text),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row {
            Tx(title, 13, modifier = Modifier.weight(1f))
            Tx(shown, 12, Mute, FontWeight.Normal)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Coral, activeTrackColor = Coral, inactiveTrackColor = Color(0x22000000))
        )
    }
}

@Composable
fun Swatches(colors: List<Pair<String, Color>>, sel: String, onSel: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for ((k, c) in colors) {
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(c).border(if (k == sel) 3.dp else 1.dp, if (k == sel) Ink else Hair, CircleShape)
                    .clickable { onSel(k) }
            )
        }
    }
}

@Composable
fun Header(title: String, sub: String = "", onBack: (() -> Unit)? = null, action: String = "Done") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx(title, 26)
            if (sub.isNotEmpty()) Tx(sub, 13, Mute, FontWeight.Normal)
        }
        if (onBack != null) Btn(action, filled = true, onClick = onBack)
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

/** Three soft lamps of colour that drift and breathe. Calm when idle, quicker when busy. */
@Composable
fun Blob(level: Int, modifier: Modifier = Modifier, height: Dp = 150.dp) {
    val tr = rememberInfiniteTransition(label = "blob")
    val ms = when (level) { 2 -> 2600; 1 -> 4200; else -> 8000 }
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing)), label = "t")
    val cols = listOf(Coral, Violet, SkyBlue)
    Canvas(modifier.fillMaxWidth().height(height)) {
        val w = size.width
        val h = size.height
        val r = min(w, h) * 0.42f
        val a = 2f * PI.toFloat() * t
        val base = if (level == 0) 0.38f else 0.62f
        for (i in 0..2) {
            val ang = a + i * 2.094f
            val cx = w / 2f + cos(ang) * r * 0.55f
            val cy = h / 2f + sin(ang * 1.1f) * r * 0.3f
            val rad = r * (0.9f + 0.12f * sin(a * 2f + i))
            drawCircle(
                Brush.radialGradient(listOf(cols[i].copy(alpha = base), Color.Transparent), Offset(cx, cy), rad),
                rad, Offset(cx, cy)
            )
        }
    }
}

// ---- permission and setting checks

fun has(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

fun wantedPerms(): Array<String> {
    val l = arrayListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    return l.toTypedArray()
}

fun accOn(c: Context): Boolean {
    val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val me = ComponentName(c, Hands::class.java).flattenToString()
    return s.split(":").any { it.equals(me, true) }
}

fun batOk(c: Context): Boolean =
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

fun openSettings(c: Context, action: String) {
    try { c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

fun openAppInfo(c: Context) {
    try {
        c.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) { }
}

fun askBattery(c: Context) {
    try {
        c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        openSettings(c, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    }
}

@Composable
fun resumeTick(): Int {
    var t by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) t++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    return t
}

@Composable
fun CheckRow(text: String, done: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(24.dp).clip(CircleShape).background(if (done) Good else Color(0x22000000)), contentAlignment = Alignment.Center) {
            if (done) Tx("✓", 14, Color.White)
        }
        Spacer(Modifier.width(10.dp))
        Tx(text, 14, modifier = Modifier.weight(1f))
        if (!done && action.isNotEmpty()) Btn(action, filled = true, onClick = onClick)
    }
}

enum class Pg { Home, Commands, Edit, Look, Safety, Vocab, Try, Setup, Calibrate, Train, Mine }

@Composable
fun WaveBuddyApp() {
    var page by remember { mutableStateOf(if (Store.b("setupdone", false)) Pg.Home else Pg.Setup) }
    var editing by remember { mutableStateOf<Command?>(null) }
    var calibBack by remember { mutableStateOf(Pg.Look) }
    BackHandler(enabled = page != Pg.Home) {
        page = when (page) {
            Pg.Edit -> Pg.Commands
            Pg.Calibrate -> calibBack
            else -> Pg.Home
        }
    }
    Box(Modifier.fillMaxSize().sky()) {
        when (page) {
            Pg.Home -> HomePage { page = it }
            Pg.Commands -> CommandsPage({ page = Pg.Home }) { editing = it; page = Pg.Edit }
            Pg.Edit -> EditPage(editing) { page = Pg.Commands }
            Pg.Look -> LookPage({ page = Pg.Home }) { calibBack = Pg.Look; page = Pg.Calibrate }
            Pg.Safety -> SafetyPage { page = Pg.Home }
            Pg.Vocab -> VocabPage { page = Pg.Home }
            Pg.Try -> TryPage { page = Pg.Home }
            Pg.Setup -> SetupPage({ Store.put("setupdone", true); page = Pg.Home }) { calibBack = Pg.Setup; page = Pg.Calibrate }
            Pg.Calibrate -> CalibratePage { page = calibBack }
            Pg.Train -> TrainPage { page = Pg.Home }
            Pg.Mine -> VoiceLockPage { page = Pg.Home }
        }
    }
}

@Composable
fun HomePage(go: (Pg) -> Unit) {
    val ctx = LocalContext.current
    val tick = resumeTick()
    var bump by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bump++
        if (has(ctx, Manifest.permission.RECORD_AUDIO) && !Buddy.micOn) MicService.start(ctx)
    }
    val mic = remember(tick, bump) { has(ctx, Manifest.permission.RECORD_AUDIO) }
    val contacts = remember(tick, bump) { has(ctx, Manifest.permission.READ_CONTACTS) }
    val phone = remember(tick, bump) { has(ctx, Manifest.permission.CALL_PHONE) }
    val acc = remember(tick, bump) { accOn(ctx) }
    val bat = remember(tick, bump) { batOk(ctx) }
    val level = if (!Buddy.micOn) 0 else if (Buddy.modeName.isNotEmpty()) 2 else 1

    Page {
        Header("WaveBuddy", "Your hands-free helper. Everything stays on this phone.")
        Glass {
            Blob(level)
            Spacer(Modifier.height(4.dp))
            Tx(Buddy.status, 15, if (Buddy.micOn && !Buddy.sleeping) Good else Ink)
            if (Buddy.modeName.isNotEmpty()) Tx(Buddy.modeName, 13, Coral)
            if (Buddy.heard.isNotEmpty() && Buddy.micOn) Tx("I heard: \"" + Buddy.heard + "\"", 12, Mute, FontWeight.Normal, maxLines = 2)
            if (Buddy.modelError.isNotEmpty()) Tx(Buddy.modelError, 12, Bad, FontWeight.Normal)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn(if (Buddy.micOn) "Stop listening" else "Start listening", filled = !Buddy.micOn) {
                    if (Buddy.micOn) MicService.stop()
                    else if (mic) { Buddy.sleeping = false; MicService.start(ctx) }
                    else permLauncher.launch(wantedPerms())
                }
                if (Buddy.micOn) Btn(if (Buddy.sleeping) "Wake" else "Sleep") {
                    Buddy.sleeping = !Buddy.sleeping
                    MicService.refreshGate()
                    Hands.inst?.setFabMode()
                }
            }
        }

        if (!mic || !acc || !bat || !contacts || !phone) {
            Glass {
                Tx("Finish setting up", 16)
                Spacer(Modifier.height(6.dp))
                CheckRow("Microphone", mic, "Allow") { permLauncher.launch(wantedPerms()) }
                CheckRow("WaveBuddy Hands (Accessibility)", acc, "Open") { openSettings(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
                if (!acc) Tx("Greyed out? Open the guided setup, step 2 shows the fix.", 12, Mute, FontWeight.Normal)
                CheckRow("Contacts and calls", contacts && phone, "Allow") { permLauncher.launch(wantedPerms()) }
                CheckRow("Battery set to Unrestricted", bat, "Fix") { askBattery(ctx) }
                Spacer(Modifier.height(6.dp))
                Btn("Open guided setup", onClick = { go(Pg.Setup) })
            }
        }

        Glass {
            Nav("Commands", "Starter pack, your own commands, teach by showing") { go(Pg.Commands) }
            Nav("Look and feel", "Floating words, glow ring, round button") { go(Pg.Look) }
            Nav("Safety", "Ask before calling, secret phrase, what it may do") { go(Pg.Safety) }
            Nav("Train me", "Teach commands by saying them, fix what I got wrong") { go(Pg.Train) }
            Nav("Only my voice", "Ignore everyone except you") { go(Pg.Mine) }
            Nav("My words", "Teach it names, like \"mum\" means Mum Mobile") { go(Pg.Vocab) }
            Nav("Try it", "Type a command and see what it would do") { go(Pg.Try) }
            Nav("Guided setup", "The three-minute first run again") { go(Pg.Setup) }
        }

        Glass {
            Tx("Lately", 16)
            Spacer(Modifier.height(4.dp))
            if (Buddy.log.isEmpty()) Tx("Nothing yet. Say \"" + Store.wake + "\" and a command.", 13, Mute, FontWeight.Normal)
            val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
            for (r in Buddy.log.take(8)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Tx(if (r.ok) "✓" else "✕", 15, if (r.ok) Good else Bad, modifier = Modifier.width(22.dp))
                    Column(Modifier.weight(1f)) {
                        Tx(r.did.ifEmpty { "-" }, 13, maxLines = 1)
                        Tx("\"" + r.heard + "\"", 12, Mute, FontWeight.Normal, maxLines = 1)
                        if (!r.ok && r.why.isNotEmpty()) Tx(r.why, 12, Bad, FontWeight.Normal)
                    }
                    Tx(fmt.format(Date(r.time)), 11, Mute, FontWeight.Normal)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
fun Nav(title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx(title, 15)
            Tx(sub, 12, Mute, FontWeight.Normal)
        }
        Tx("›", 22, Mute)
    }
}
