package com.breadwinner.wavebuddy

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LogRow(val time: Long, val heard: String, val did: String, val ok: Boolean, val why: String)

/** What the screens show: what was heard, whether the voice engine is ready, and the recent log. */
object Buddy {
    var heard by mutableStateOf("")
    var status by mutableStateOf("Not listening")
    var modelReady by mutableStateOf(false)
    var modelError by mutableStateOf("")
    var micOn by mutableStateOf(false)
    var sleeping by mutableStateOf(false)
    var wakeCount by mutableStateOf(0)
    var modeName by mutableStateOf("")
    val log = mutableStateListOf<LogRow>()
    val did = mutableStateMapOf<String, Boolean>()

    fun addLog(heard: String, did: String, ok: Boolean, why: String = "") {
        Handler(Looper.getMainLooper()).post {
            log.add(0, LogRow(System.currentTimeMillis(), heard, did, ok, why))
            while (log.size > 60) log.removeAt(log.size - 1)
        }
    }
}

object Voice {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var tone: ToneGenerator? = null

    fun say(text: String) {
        if (!Store.speak) return
        try {
            if (tts == null) tts = TextToSpeech(Store.app) { st -> ready = st == TextToSpeech.SUCCESS }
            if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wb")
        } catch (e: Exception) {
        }
    }

    /** A short, quiet sound for each state: 0 woke, 1 done, 2 problem. */
    fun cue(kind: Int) {
        if (!Store.cues) return
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 45)
            val t = when (kind) {
                0 -> ToneGenerator.TONE_PROP_ACK
                1 -> ToneGenerator.TONE_PROP_PROMPT
                else -> ToneGenerator.TONE_PROP_NACK
            }
            tone?.startTone(t, 90)
        } catch (e: Exception) {
        }
    }
}

/** Decides what a heard sentence means right now: wake word, command, answer, dictation or teaching. */
object Brain {
    enum class Mode { IDLE, LISTEN, DICTATE, CONFIRM, SECRET, TEACH, RECORDING, TRAIN }

    @Volatile var mode = Mode.IDLE
    private var pending: Plan? = null
    private var awakeUntil = 0L
    @Volatile var pttHeld = false
    @Volatile private var pttUntil = 0L
    private var wakeFlash = false
    var recPhrase = ""
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val idleCheck = Runnable { checkIdle() }

    private val yes = setOf("yes", "yeah", "yep", "yup", "sure", "ok", "okay", "do it", "confirm", "go ahead", "correct", "right", "yes please")
    private val no = setOf("no", "nope", "cancel", "stop", "never mind", "nevermind", "don't", "dont", "no thanks")
    private val doneWords = setOf("done", "finished", "that's it", "thats it", "stop recording", "save it", "save", "i'm done", "im done")
    private val stopTyping = setOf("stop typing", "stop dictation", "done typing", "end dictation", "stop")

    val forced: Boolean get() = pttHeld || System.currentTimeMillis() < pttUntil

    fun switchMode(m: Mode) {
        mode = m
        Buddy.modeName = when (m) {
            Mode.DICTATE -> "Typing what you say"
            Mode.CONFIRM -> "Waiting for yes or no"
            Mode.SECRET -> "Waiting for your secret phrase"
            Mode.TEACH -> "Teaching: say the phrase"
            Mode.RECORDING -> "Recording your steps"
            Mode.TRAIN -> "Training: say the phrase"
            Mode.LISTEN -> "Listening"
            else -> ""
        }
    }

    private val heyWords = setOf("hey", "hay", "hi", "a", "hey,", "he", "hate", "ay", "eh", "okay", "ok", "oh", "hello", "hail", "high")

    private fun wakeRest(t: String): String? {
        val wake = Norm.clean(Store.wake)
        val ww = wake.split(" ")
        val words = t.split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        // ways of saying the wake word that you taught me
        for (v in Learn.wakes) {
            if (t == v) return ""
            if (t.startsWith("$v ")) return t.removePrefix("$v ")
        }
        // the full phrase, spoken a little differently
        for (k in listOf(ww.size, ww.size + 1, ww.size - 1)) {
            if (k < 1 || k > words.size) continue
            val head = words.take(k).joinToString("")
            if (Norm.sim(head, wake.replace(" ", "")) >= 0.66f) return words.drop(k).joinToString(" ")
        }
        // the name part ("buddy") heard in the first three words, even if "hey" came out as something else
        val name = ww.last()
        if (name.length >= 3) {
            for (i in 0 until minOf(3, words.size)) {
                val w = words[i]
                val close = Norm.sim(w, name) >= 0.6f || (w.length >= 3 && Norm.soundex(w) == Norm.soundex(name))
                val lead = i == 0 || words.take(i).all { it in heyWords || it.length <= 3 }
                if (close && lead) return words.drop(i + 1).joinToString(" ")
            }
        }
        return null
    }

    // ---- hold to talk (the floating button)

    fun pttStart() {
        pttHeld = true
        main.post {
            MicService.active(true)
            Fx.state(RingState.LISTEN)
            Voice.cue(0)
        }
    }

    fun pttEnd() {
        pttHeld = false
        pttUntil = System.currentTimeMillis() + 1800
        main.postDelayed({ MicService.refreshGate() }, 2200)
    }

    /** A tap on the button: listen for one command, no wake word needed. */
    fun pttTap() {
        pttUntil = System.currentTimeMillis() + 7000
        main.post {
            MicService.active(true)
            Fx.state(RingState.LISTEN)
            Fx.words("Listening", "", 900)
            Voice.cue(0)
        }
        main.postDelayed({ MicService.refreshGate() }, 7500)
    }

    // ---- what the engine tells us

    fun onPartial(text: String) {
        val t = Norm.clean(text)
        if (t.isEmpty()) return
        Buddy.heard = t
        main.post {
            if (mode == Mode.IDLE && !forced) {
                if (!wakeFlash && Store.b("wakeon", true) && wakeRest(t) != null) {
                    wakeFlash = true
                    Fx.state(RingState.LISTEN)
                }
            } else {
                Fx.state(RingState.HEAR)
            }
        }
    }

    fun onFinal(text: String) {
        val t = Norm.clean(text)
        if (t.isEmpty()) return
        Buddy.heard = t
        main.post { handle(t) }
    }

    private fun handle(t0: String) {
        if (mode == Mode.TRAIN) {
            Learn.sample(t0)
            return
        }
        wakeFlash = false
        var t = t0
        val f = forced
        if (mode == Mode.IDLE || mode == Mode.LISTEN && System.currentTimeMillis() > awakeUntil) {
            val rest = wakeRest(t)
            if (rest != null && (Store.b("wakeon", true) || f)) {
                switchMode(Mode.LISTEN)
                awake()
                Voice.cue(0)
                Buddy.wakeCount++
                if (rest.isBlank()) {
                    val name = Norm.clean(Store.wake).split(" ").last().replaceFirstChar { it.uppercase() }
                    Fx.state(RingState.LISTEN)
                    Fx.words(name, "", 900)
                    return
                }
                t = rest
            } else if (!f) {
                Fx.state(RingState.IDLE)
                if (mode == Mode.LISTEN) switchMode(Mode.IDLE)
                return
            } else {
                switchMode(Mode.LISTEN)
            }
        } else if (mode == Mode.LISTEN) {
            // already awake: allow a repeated wake word in front
            wakeRest(t)?.let { if (it.isNotBlank()) t = it }
        }
        process(t)
    }

    private fun awake() {
        awakeUntil = System.currentTimeMillis() + Store.stayAwake * 1000L
        main.removeCallbacks(idleCheck)
        main.postDelayed(idleCheck, Store.stayAwake * 1000L + 300)
    }

    private fun checkIdle() {
        if (mode == Mode.LISTEN && System.currentTimeMillis() >= awakeUntil) {
            switchMode(Mode.IDLE)
            Fx.state(RingState.IDLE)
        }
    }

    private fun process(t: String) {
        when (mode) {
            Mode.DICTATE -> {
                if (stopTyping.contains(t)) { endDictation(); return }
                runPlan(Plan("Typing", listOf(Step("TYPE", Norm.pretty(t) + " ")), trivial = true), t, false)
                return
            }
            Mode.CONFIRM -> {
                if (yes.contains(t)) {
                    val p = pending
                    pending = null
                    switchMode(Mode.LISTEN)
                    if (p != null) runPlan(p, t, true)
                } else if (no.contains(t)) {
                    pending = null
                    switchMode(Mode.LISTEN)
                    Fx.words("Okay, cancelled", "", 900)
                    Buddy.addLog(t, "Cancelled", true)
                } else {
                    Fx.words("Say yes or no", "", 900)
                }
                awake()
                return
            }
            Mode.SECRET -> {
                if (Norm.clean(Store.secret) == t) {
                    val p = pending
                    pending = null
                    switchMode(Mode.LISTEN)
                    if (p != null) runPlan(p, t, true)
                } else {
                    pending = null
                    switchMode(Mode.LISTEN)
                    Fx.state(RingState.PROBLEM)
                    Fx.words("That wasn't the phrase", "Cancelled.", 1300)
                    Buddy.addLog(t, "Secret phrase", false, "Wrong phrase, so nothing was done.")
                }
                return
            }
            Mode.TEACH -> {
                val phrase = t
                Fx.words("Okay, show me", "Do it on the phone, then say \"done\"", 2200)
                startRecording(phrase)
                return
            }
            Mode.RECORDING -> {
                val w = Norm.words(t).joinToString(" ")
                if (doneWords.contains(w) || doneWords.contains(t)) stopRecording(true)
                return
            }
            else -> {}
        }

        val res = Parser.parse(Learn.fix(t))
        val plan = res.plan
        if (plan == null) {
            Learn.miss(t)
            Fx.state(RingState.PROBLEM)
            Voice.cue(2)
            if (res.fail.isNotEmpty()) {
                Fx.words("Hmm", res.fail, 2000)
                Buddy.addLog(t, "-", false, res.fail)
            } else {
                Fx.words("Hmm, not sure", "I heard: \"$t\"", 1800)
                Buddy.addLog(t, "-", false, "I didn't recognise that as a command.")
            }
            awake()
            return
        }
        if (res.ask) {
            pending = plan
            switchMode(Mode.CONFIRM)
            Fx.state(RingState.LISTEN)
            Fx.words("Did you mean…", plan.label + "?  Say yes or no.", 8000)
            awake()
            return
        }
        runPlan(plan, t, false)
    }

    private fun needsConfirm(p: Plan): Boolean {
        val c = Store.confirm
        if (c == "never") return false
        if (p.trivial && !p.risky) return p.ask && false
        return when (c) {
            "always" -> !p.trivial || p.risky
            else -> p.risky || p.ask
        }
    }

    private fun runPlan(p: Plan, heard: String, confirmed: Boolean) {
        if (!confirmed) {
            val sensitive = p.risky && Store.secret.isNotBlank()
            if (sensitive) {
                pending = p
                switchMode(Mode.SECRET)
                Fx.state(RingState.LISTEN)
                Fx.words(p.label, "Say your secret phrase to go ahead.", 8000)
                awake()
                return
            }
            if (needsConfirm(p)) {
                pending = p
                switchMode(Mode.CONFIRM)
                Fx.state(RingState.LISTEN)
                Fx.words(p.label, "Say yes to confirm.", 8000)
                Voice.say(p.label + ". Say yes to confirm.")
                awake()
                return
            }
        }
        Fx.state(RingState.THINK)
        scope.launch {
            val fail = Runner.run(p)
            if (fail == null) {
                Fx.state(RingState.DONE)
                Voice.cue(1)
                if (mode != Mode.DICTATE && p.label != "Typing") Fx.words(p.label, "", 1100)
                Buddy.addLog(heard, p.label, true)
                for (s in p.steps) Buddy.did[s.type] = true
                Voice.say(p.label)
            } else {
                Fx.state(RingState.PROBLEM)
                Voice.cue(2)
                Fx.words("Couldn't do that", fail, 2400)
                Buddy.addLog(heard, p.label, false, fail)
                Voice.say(fail)
            }
            if (mode == Mode.LISTEN) awake()
        }
    }

    // ---- modes that other parts call

    fun startDictation() {
        switchMode(Mode.DICTATE)
        Fx.words("Typing", "Say \"stop typing\" when you're done.", 1600)
    }

    fun endDictation() {
        switchMode(Mode.LISTEN)
        awake()
        Fx.words("Typing off", "", 900)
    }

    fun sleep() {
        switchMode(Mode.IDLE)
        Buddy.sleeping = true
        MicService.refreshGate()
        Fx.state(RingState.IDLE)
        Fx.words("Sleeping", "Tap the round button to wake me.", 1800)
        Hands.inst?.setFabMode()
    }

    fun cancel() {
        pending = null
        if (mode == Mode.TRAIN) Learn.stop()
        if (mode == Mode.RECORDING) stopRecording(false)
        switchMode(if (mode == Mode.IDLE) Mode.IDLE else Mode.LISTEN)
        Fx.clearWords()
    }

    fun startTeach() {
        switchMode(Mode.TEACH)
        Fx.state(RingState.LISTEN)
        Fx.words("What will you say?", "Say the phrase for your new command.", 4000)
    }

    fun startRecording(phrase: String) {
        recPhrase = phrase
        val h = Hands.inst
        if (h == null) {
            Fx.words("Hands are off", "Switch on WaveBuddy Hands in Accessibility.", 2500)
            switchMode(Mode.LISTEN)
            return
        }
        h.startRecording()
        switchMode(Mode.RECORDING)
        Fx.state(RingState.LISTEN)
    }

    fun stopRecording(save: Boolean) {
        val h = Hands.inst
        val steps = h?.finishRecording() ?: emptyList()
        switchMode(Mode.LISTEN)
        awake()
        if (!save) {
            Fx.words("Recording cancelled", "", 1000)
            return
        }
        if (steps.isEmpty()) {
            Fx.state(RingState.PROBLEM)
            Fx.words("I didn't see any steps", "Try again and tap things on the screen.", 2200)
            Buddy.addLog(recPhrase, "Teach", false, "No steps were recorded.")
            return
        }
        val phrase = recPhrase.trim()
        Store.cmds.removeAll { it.phrase.equals(phrase, true) }
        Store.cmds.add(Command(Store.newId(), phrase, steps))
        Store.saveCmds()
        Fx.state(RingState.DONE)
        Fx.words("Saved", "\"$phrase\" with ${steps.size} steps", 2200)
        Buddy.addLog(phrase, "Saved a new command", true)
    }

    /** For the Try-it screen: says what a sentence would do without doing it. */
    fun explain(text: String): String {
        val r = Parser.parse(text)
        val p = r.plan ?: return if (r.fail.isNotEmpty()) r.fail else "Not a command I know."
        val steps = p.steps.joinToString(", ") { s ->
            s.type.lowercase().replace('_', ' ') + (if (s.a.isNotEmpty()) " \"${s.a}\"" else "") + (if (s.n != 0) " ${s.n}" else "")
        }
        return (if (r.ask) "Would ask: Did you mean \"${p.label}\"?  " else "") + p.label + "  →  " + steps
    }

    /** For the Try-it screen: runs it as if you had said it. */
    fun typed(text: String) {
        main.post {
            switchMode(Mode.LISTEN)
            awake()
            Buddy.heard = text
            process(Norm.clean(text))
        }
    }
}
