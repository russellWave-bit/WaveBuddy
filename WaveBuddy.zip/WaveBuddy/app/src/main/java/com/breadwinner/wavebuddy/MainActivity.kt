package com.breadwinner.wavebuddy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Coral, background = Color(0xFFFFF8F0), surface = Color.White)) {
                WaveBuddyApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (Store.listening && !Buddy.micOn && MicService.hasMic(this)) MicService.start(this)
    }
}
