package com.breadwinner.wavebuddy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            val scheme = if (night()) darkColorScheme(
                primary = Coral, onPrimary = OnAccent, background = Cream, surface = Paper, surfaceContainer = Paper,
                onSurface = Ink, onBackground = Ink
            ) else lightColorScheme(
                primary = Coral, onPrimary = OnAccent, background = Cream, surface = Paper, surfaceContainer = Paper,
                onSurface = Ink, onBackground = Ink
            )
            MaterialTheme(colorScheme = scheme) {
                WaveBuddyApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (Store.listening && !Buddy.micOn && MicService.hasMic(this)) MicService.start(this)
    }
}
