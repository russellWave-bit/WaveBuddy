package com.breadwinner.wavebuddy

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** WaveBuddy Hands: the Accessibility service that taps, swipes and types, and hosts the glow and floating words. */
class Hands : AccessibilityService() {
    companion object {
        @Volatile var inst: Hands? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    var fx: FxView? = null
    private var fab: FabView? = null
    private var fabLp: WindowManager.LayoutParams? = null

    private var numList: List<Pair<NumBadge, AccessibilityNodeInfo>> = emptyList()
    var numbersOn = false
        private set
    private val gridStack = ArrayList<RectF>()
    val gridOn: Boolean get() = gridStack.isNotEmpty()
    private var grabPt: PointF? = null
    private val undoStack = ArrayList<String>()

    private var rec: ArrayList<Step>? = null
    private var recT = 0L
    private var recText: String? = null
    private var recPkg = ""

    val screenW: Int get() = fx?.width?.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
    val screenH: Int get() = fx?.height?.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store.init(this)
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addFx()
        updateFab()
        Buddy.status = if (Buddy.micOn) Buddy.status else "Hands are on"
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeAll()
        inst = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeAll()
        inst = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    private fun removeAll() {
        try { fx?.let { wm?.removeView(it) } } catch (e: Exception) { }
        try { fab?.let { wm?.removeView(it) } } catch (e: Exception) { }
        fx = null
        fab = null
    }

    // ---- overlays

    private fun addFx() {
        if (fx != null) return
        val v = FxView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try {
            wm?.addView(v, lp)
            fx = v
            v.post {
                if (!Store.m.containsKey("rcal")) findCamera()
                v.invalidate()
            }
        } catch (e: Exception) {
            Buddy.status = "Couldn't draw on screen: " + (e.message ?: "")
        }
    }

    /** Finds the camera hole from Android's own cutout information and puts the ring on it. */
    fun findCamera(): Boolean {
        val v = fx ?: return false
        val cut = v.rootWindowInsets?.displayCutout ?: return false
        val rects = cut.boundingRects.filter { it.top <= 2 && it.width() > 0 }
        val r = rects.minByOrNull { it.width() * it.height() } ?: return false
        val w = max(1, v.width).toFloat()
        val h = max(1, v.height).toFloat()
        Store.put("rx", r.exactCenterX() / w)
        Store.put("ry", r.exactCenterY() / h)
        Store.put("rr", min(r.width(), r.height()) / 2f / w)
        Store.put("rcal", true)
        v.invalidate()
        return true
    }

    fun refresh() {
        main.post {
            fx?.invalidate()
            updateFab()
        }
    }

    private fun updateFab() {
        if (Store.fabOn && fab == null) addFab()
        else if (!Store.fabOn && fab != null) {
            try { wm?.removeView(fab) } catch (e: Exception) { }
            fab = null
        }
        setFabMode()
    }

    fun setFabMode() {
        val f = fab ?: return
        f.mode = when {
            Brain.mode == Brain.Mode.RECORDING -> 2
            Buddy.sleeping -> 1
            Brain.pttHeld -> 3
            else -> 0
        }
        f.invalidate()
    }

    private fun addFab() {
        val v = FabView(this)
        val size = (54 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val edge = (4 * resources.displayMetrics.density).toInt()
        lp.x = if (Store.fabX < 0.5f) edge else max(0, screenW - size - edge)
        lp.y = (Store.fabY * screenH).toInt().coerceIn(0, max(0, screenH - size))
        val slop = 14 * resources.displayMetrics.density
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var holding = false
        val holdRun = Runnable {
            holding = true
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            Brain.pttStart()
            setFabMode()
        }
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y
                    moved = false; holding = false
                    main.postDelayed(holdRun, 330)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!holding && (abs(dx) > slop || abs(dy) > slop)) { moved = true; main.removeCallbacks(holdRun) }
                    if (moved && !holding) {
                        lp.x = (startX + dx).toInt().coerceIn(0, max(0, screenW - size))
                        lp.y = (startY + dy).toInt().coerceIn(0, max(0, screenH - size))
                        try { wm?.updateViewLayout(v, lp) } catch (e: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(holdRun)
                    if (holding) {
                        Brain.pttEnd()
                        setFabMode()
                    } else if (moved) {
                        // glide to the nearest side and stay on the edge
                        val left = lp.x + size / 2 < screenW / 2
                        val target = if (left) edge else max(0, screenW - size - edge)
                        val from = lp.x
                        val anim = android.animation.ValueAnimator.ofInt(from, target)
                        anim.duration = 220
                        anim.interpolator = android.view.animation.DecelerateInterpolator()
                        anim.addUpdateListener { a ->
                            lp.x = a.animatedValue as Int
                            try { wm?.updateViewLayout(v, lp) } catch (e: Exception) { }
                        }
                        anim.start()
                        Store.put("fabx", if (left) 0f else 1f)
                        Store.put("faby", lp.y.toFloat() / max(1, screenH))
                    } else if (ev.actionMasked == MotionEvent.ACTION_UP) {
                        onFabTap()
                    }
                }
            }
            true
        }
        try {
            wm?.addView(v, lp)
            fab = v
            fabLp = lp
        } catch (e: Exception) {
        }
    }

    private fun onFabTap() {
        when {
            Brain.mode == Brain.Mode.RECORDING -> Brain.stopRecording(true)
            !Buddy.micOn -> Fx.words("Open WaveBuddy", "Tap Start there first.", 2200)
            Buddy.sleeping -> {
                Buddy.sleeping = false
                MicService.refreshGate()
                Fx.words("I'm listening again", "", 1200)
            }
            else -> Brain.pttTap()
        }
        setFabMode()
    }

    // ---- watching what happens (numbers refresh, and recording your steps)

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        e ?: return
        val pkg = e.packageName?.toString() ?: ""
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && numbersOn && pkg != packageName) {
            main.removeCallbacks(refreshNums)
            main.postDelayed(refreshNums, 600)
        }
        val r = rec ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg.isEmpty()) return
        val isLauncher = pkg.contains("launcher")
        val now = System.currentTimeMillis()
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (!isLauncher && pkg != recPkg) {
                    flushText()
                    recPkg = pkg
                    r.add(Step("OPEN_APP", pkg))
                    recT = now
                }
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                if (isLauncher) return
                flushText()
                val n = e.source
                val label = n?.let { (it.text?.toString() ?: "").ifBlank { it.contentDescription?.toString() ?: "" } } ?: ""
                val wait = ((now - recT).coerceIn(500L, 1600L)).toInt()
                r.add(Step("WAIT", n = wait))
                if (label.isNotBlank() && label.length <= 40) r.add(Step("TAP_TEXT", label))
                else if (n?.viewIdResourceName != null) r.add(Step("TAP_ID", n.viewIdResourceName))
                else if (n != null) {
                    val b = Rect()
                    n.getBoundsInScreen(b)
                    r.add(Step("TAP_XY", String.format(java.util.Locale.US, "%.3f,%.3f", b.exactCenterX() / screenW, b.exactCenterY() / screenH)))
                }
                recT = now
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                if (e.isPassword) return
                recText = e.text.joinToString("")
                recT = now
            }
        }
    }

    private fun flushText() {
        val t = recText
        recText = null
        val r = rec ?: return
        if (t != null && t.isNotBlank()) {
            r.add(Step("WAIT", n = 400))
            r.add(Step("TYPE", t))
        }
    }

    fun startRecording() {
        rec = ArrayList()
        recT = System.currentTimeMillis()
        recText = null
        recPkg = ""
        setFabMode()
    }

    fun finishRecording(): List<Step> {
        flushText()
        val r = rec ?: emptyList<Step>()
        rec = null
        setFabMode()
        // drop leading and trailing waits
        val list = ArrayList(r)
        while (list.isNotEmpty() && list.first().type == "WAIT") list.removeAt(0)
        while (list.isNotEmpty() && list.last().type == "WAIT") list.removeAt(list.size - 1)
        return list
    }

    // ---- finding things on the screen

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { out.add(it) }
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == packageName) continue
                if (out.none { it.windowId == r.windowId }) out.add(r)
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: "").ifBlank { n.contentDescription?.toString() ?: "" }

    private fun pick(alt: String): AccessibilityNodeInfo? {
        val a = alt.trim().lowercase()
        if (a.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bs = 0
        val rs = roots()
        for (r in rs) {
            val list = try { r.findAccessibilityNodeInfosByText(alt.trim()) ?: emptyList() } catch (e: Exception) { emptyList<AccessibilityNodeInfo>() }
            for (n in list) {
                if (!n.isVisibleToUser) continue
                val t = (n.text?.toString() ?: "").lowercase()
                val d = (n.contentDescription?.toString() ?: "").lowercase()
                var sc = when {
                    t == a || d == a -> 100
                    t.startsWith(a) || d.startsWith(a) -> 70
                    else -> 40
                }
                sc -= min(30, max(t.length, d.length) / 6)
                if (n.isClickable) sc += 5
                if (n.isEditable) sc -= 25
                if (sc > bs) { bs = sc; best = n }
            }
        }
        if (best != null) return best
        for (r in rs) {
            val f = fuzzy(r, a, 0)
            if (f != null) return f
        }
        return null
    }

    private fun fuzzy(n: AccessibilityNodeInfo, a: String, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30) return null
        if (n.isVisibleToUser) {
            val l = label(n).lowercase()
            if (l.isNotEmpty() && l.length < 40 && !n.isEditable && Norm.sim(a, l) >= 0.8f) return n
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = fuzzy(c, a, depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun click(node: AccessibilityNodeInfo, long: Boolean): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 7) {
            if (if (long) n.isLongClickable else n.isClickable) {
                if (n.performAction(if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            n = n.parent
            hops++
        }
        val b = Rect()
        node.getBoundsInScreen(b)
        if (b.isEmpty) return false
        tapAt(b.exactCenterX(), b.exactCenterY(), long)
        return true
    }

    suspend fun tapText(q: String, long: Boolean, waitMs: Long): Boolean {
        val alts = q.split("|").map { it.trim() }.filter { it.isNotEmpty() }
        val end = System.currentTimeMillis() + waitMs
        while (true) {
            for (a in alts) {
                val n = pick(a)
                if (n != null) return click(n, long)
            }
            if (System.currentTimeMillis() >= end) return false
            delay(180)
        }
    }

    suspend fun tapId(id: String, waitMs: Long): Boolean {
        val end = System.currentTimeMillis() + waitMs
        while (true) {
            for (r in roots()) {
                val l = try { r.findAccessibilityNodeInfosByViewId(id) ?: emptyList() } catch (e: Exception) { emptyList<AccessibilityNodeInfo>() }
                for (n in l) if (n.isVisibleToUser) return click(n, false)
            }
            if (System.currentTimeMillis() >= end) return false
            delay(180)
        }
    }

    // ---- gestures

    fun tapAt(x: Float, y: Float, long: Boolean) {
        val p = Path()
        p.moveTo(x, y)
        p.lineTo(x + 0.5f, y)
        try {
            dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0L, if (long) 750L else 60L)).build(), null, null)
        } catch (e: Exception) {
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        try {
            dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0L, dur)).build(), null, null)
        } catch (e: Exception) {
        }
    }

    fun global(code: Int): Boolean = performGlobalAction(code)

    private fun scrollable(n: AccessibilityNodeInfo, depth: Int, best: Array<AccessibilityNodeInfo?>, area: IntArray) {
        if (depth > 30) return
        if (n.isVisibleToUser && n.isScrollable) {
            val b = Rect()
            n.getBoundsInScreen(b)
            val a = b.width() * b.height()
            if (a > area[0]) { area[0] = a; best[0] = n }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            scrollable(c, depth + 1, best, area)
        }
    }

    suspend fun scroll(dir: String): Boolean {
        val f = Store.f("scrollf", 1f)
        val best = arrayOfNulls<AccessibilityNodeInfo>(1)
        val area = intArrayOf(0)
        val r = rootInActiveWindow
        if (r != null) scrollable(r, 0, best, area)
        val n = best[0]
        if (n != null) {
            val act = when (dir) {
                "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id
                "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id
                "right" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id
                else -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
            }
            val times = max(1, (f + 0.4f).toInt())
            var ok = false
            for (k in 1..times) {
                ok = n.performAction(act) || ok
                if (k < times) delay(260)
            }
            if (ok) return true
        }
        val w = screenW.toFloat()
        val h = screenH.toFloat()
        val d = 0.22f * f.coerceIn(0.5f, 2.5f)
        when (dir) {
            "up" -> swipe(w / 2, h * (0.5f - d), w / 2, h * (0.5f + d), 260)
            "left" -> swipe(w * (0.5f - d), h / 2, w * (0.5f + d), h / 2, 260)
            "right" -> swipe(w * (0.5f + d), h / 2, w * (0.5f - d), h / 2, 260)
            else -> swipe(w / 2, h * (0.5f + d), w / 2, h * (0.5f - d), 260)
        }
        delay(300)
        return true
    }

    // ---- typing

    private fun editable(n: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30) return null
        if (n.isVisibleToUser && n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = editable(c, depth + 1)
            if (r != null) return r
        }
        return null
    }

    private fun inputNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        return editable(root, 0)
    }

    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    suspend fun typeText(t: String): Boolean {
        var node = inputNode()
        if (node == null) {
            delay(500)
            node = inputNode()
        }
        val n = node ?: return false
        val cur = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        undoStack.add(cur)
        if (undoStack.size > 20) undoStack.removeAt(0)
        return setText(n, cur + t)
    }

    fun undoType(): Boolean {
        if (undoStack.isEmpty()) return false
        val n = inputNode() ?: return false
        val prev = undoStack.removeAt(undoStack.size - 1)
        return setText(n, prev)
    }

    fun clearText(): Boolean {
        val n = inputNode() ?: return false
        val cur = if (n.isShowingHintText) "" else (n.text?.toString() ?: "")
        undoStack.add(cur)
        return setText(n, "")
    }

    suspend fun sendIt(): Boolean {
        if (tapText("Send|Send message", false, 700)) return true
        if (Build.VERSION.SDK_INT >= 30) {
            val n = inputNode()
            if (n != null && n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
        }
        return false
    }

    fun screenText(): String {
        val sb = StringBuilder()
        val seen = HashSet<String>()
        fun walk(n: AccessibilityNodeInfo, d: Int) {
            if (d > 30 || sb.length > 900) return
            if (n.isVisibleToUser) {
                val l = label(n).trim()
                if (l.isNotEmpty() && seen.add(l)) sb.append(l).append(". ")
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, d + 1) }
        }
        rootInActiveWindow?.let { walk(it, 0) }
        return sb.toString().trim()
    }

    // ---- numbers

    private val refreshNums = Runnable { if (numbersOn) setNumbers(true) }

    private fun collect(n: AccessibilityNodeInfo, out: ArrayList<Pair<Rect, AccessibilityNodeInfo>>, depth: Int) {
        if (depth > 40 || out.size > 140) return
        if (!n.isVisibleToUser) return
        if (n.isClickable || n.isEditable || n.isCheckable) {
            val b = Rect()
            n.getBoundsInScreen(b)
            val minPx = 14 * resources.displayMetrics.density
            if (b.width() >= minPx && b.height() >= minPx && b.right > 0 && b.bottom > 0 && b.left < screenW && b.top < screenH) {
                if (out.none { it.first == b }) out.add(b to n)
            }
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            collect(c, out, depth + 1)
        }
    }

    fun setNumbers(on: Boolean): Int {
        if (!on) {
            numbersOn = false
            numList = emptyList()
            fx?.badges = emptyList()
            return 0
        }
        val found = ArrayList<Pair<Rect, AccessibilityNodeInfo>>()
        for (r in roots()) collect(r, found, 0)
        val row = 28 * resources.displayMetrics.density
        found.sortWith(compareBy<Pair<Rect, AccessibilityNodeInfo>>({ (it.first.top / row).toInt() }, { it.first.left }))
        val list = ArrayList<Pair<NumBadge, AccessibilityNodeInfo>>()
        for ((i, p) in found.withIndex()) list.add(NumBadge(i + 1, p.first) to p.second)
        numList = list
        numbersOn = list.isNotEmpty()
        fx?.badges = list.map { it.first }
        return list.size
    }

    fun tapNum(n: Int, long: Boolean): Boolean {
        val hit = numList.firstOrNull { it.first.n == n } ?: return false
        val ok = click(hit.second, long)
        if (numbersOn) {
            main.removeCallbacks(refreshNums)
            main.postDelayed(refreshNums, 800)
        }
        return ok
    }

    // ---- screen grid (zooms in a square at a time)

    private fun show() {
        fx?.gridRegion = gridStack.lastOrNull()?.let { RectF(it) }
    }

    fun gridOpen() {
        gridStack.clear()
        gridStack.add(RectF(0f, 0f, screenW.toFloat(), screenH.toFloat()))
        show()
    }

    fun gridClose() {
        gridStack.clear()
        grabPt = null
        fx?.gridMark = null
        fx?.gridRegion = null
    }

    fun gridUp() {
        if (gridStack.size > 1) {
            gridStack.removeAt(gridStack.size - 1)
            show()
        } else gridClose()
    }

    fun gridPick(n: Int): String? {
        val g = gridStack.lastOrNull() ?: return "Say \"grid\" first."
        if (n !in 1..9) return "Pick a square from 1 to 9."
        val cw = g.width() / 3f
        val ch = g.height() / 3f
        val row = (n - 1) / 3
        val col = (n - 1) % 3
        gridStack.add(RectF(g.left + col * cw, g.top + row * ch, g.left + (col + 1) * cw, g.top + (row + 1) * ch))
        show()
        return null
    }

    fun gridTap(long: Boolean): String? {
        val g = gridStack.lastOrNull() ?: return "Say \"grid\" and pick a square first."
        gridClose()
        main.postDelayed({ tapAt(g.centerX(), g.centerY(), long) }, 120)
        return null
    }

    fun gridGrab(): String? {
        val g = gridStack.lastOrNull() ?: return "Say \"grid\" and pick a square first."
        grabPt = PointF(g.centerX(), g.centerY())
        fx?.gridMark = grabPt
        gridStack.clear()
        gridStack.add(RectF(0f, 0f, screenW.toFloat(), screenH.toFloat()))
        show()
        Fx.words("Grabbed", "Pick the place to drop, then say \"drop\".", 2400)
        return null
    }

    fun gridDrop(): String? {
        val from = grabPt ?: return "Nothing is grabbed. Say \"grab\" first."
        val g = gridStack.lastOrNull() ?: return "Say \"grid\" and pick where to drop."
        val tx = g.centerX()
        val ty = g.centerY()
        gridClose()
        main.postDelayed({ swipe(from.x, from.y, tx, ty, 700) }, 120)
        return null
    }
}
