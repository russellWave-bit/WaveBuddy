package com.breadwinner.wavebuddy

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * The Jarvis core: rings of light that turn at their own speeds.
 * Slow and calm when resting, quicker when it hears you, a fast sweep while it thinks,
 * a ripple when it wakes or finishes, and an inner ring that moves with your voice.
 */
@Composable
fun JarvisCore(modifier: Modifier = Modifier) {
    val on = Buddy.micOn && !Buddy.sleeping
    val phase = Buddy.phase
    var t by remember { mutableFloatStateOf(0f) }
    var spin by remember { mutableFloatStateOf(0f) }
    var amp by remember { mutableFloatStateOf(0f) }
    var pulseAt by remember { mutableFloatStateOf(-10f) }

    LaunchedEffect(phase, on) {
        if (on && (phase == RingState.LISTEN || phase == RingState.DONE || phase == RingState.PROBLEM)) pulseAt = t
    }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { n ->
                if (last != 0L) {
                    val dt = ((n - last) / 1e9f).coerceAtMost(0.1f)
                    t += dt
                    val speed = if (!Buddy.micOn || Buddy.sleeping) 0.15f else when (Buddy.phase) {
                        RingState.THINK -> 3.2f
                        RingState.LISTEN, RingState.HEAR -> 1.7f
                        RingState.DONE -> 1.1f
                        RingState.PROBLEM -> 0.3f
                        else -> 0.6f
                    }
                    spin += dt * speed
                }
                last = n
                val target = if (Buddy.micOn && !Buddy.sleeping) Ear.level else 0f
                amp += (target - amp) * 0.22f
            }
        }
    }

    val accent = when {
        !on -> Mute
        phase == RingState.PROBLEM -> Bad
        phase == RingState.THINK -> SkyBlue
        else -> Coral
    }
    val second = if (on) Violet else Mute
    val dim = if (on) 1f else 0.45f

    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val R = min(size.width, size.height) / 2f
        val px = 1f.dp2px(this)

        // soft glow behind everything
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.20f * dim), Color.Transparent), c, R * 0.85f), R * 0.85f, c)

        // outer hairline and dashed segments
        drawCircle(accent.copy(alpha = 0.22f * dim), R * 0.97f, c, style = Stroke(px))
        for (i in 0 until 24) {
            arc(c, R * 0.90f, -spin * 8f + i * 15f, 9f, accent.copy(alpha = 0.45f * dim), 2f * px)
        }

        // dial ticks
        val tickRot = spin * 4f
        for (i in 0 until 72) {
            val a = ((i * 5f + tickRot) * PI / 180f).toFloat()
            val long = i % 6 == 0
            val r1 = R * 0.80f
            val r2 = r1 - (if (long) 9f else 4f) * px
            drawLine(
                accent.copy(alpha = (if (long) 0.8f else 0.45f) * dim),
                Offset(c.x + cos(a) * r1, c.y + sin(a) * r1),
                Offset(c.x + cos(a) * r2, c.y + sin(a) * r2),
                strokeWidth = if (long) 2f * px else px
            )
        }

        // three big arcs turning together
        val big = spin * 22f
        arc(c, R * 0.68f, big, 80f, accent.copy(alpha = 0.95f * dim), 5f * px)
        arc(c, R * 0.68f, big + 140f, 50f, accent.copy(alpha = 0.7f * dim), 5f * px)
        arc(c, R * 0.68f, big + 250f, 28f, second.copy(alpha = 0.8f * dim), 5f * px)

        // thinking sweep, or a faint guide circle
        if (on && phase == RingState.THINK) {
            arc(c, R * 0.58f, spin * 70f, 28f, SkyBlue, 3f * px)
            arc(c, R * 0.58f, spin * 70f + 180f, 28f, SkyBlue, 3f * px)
        } else {
            drawCircle(second.copy(alpha = 0.25f * dim), R * 0.58f, c, style = Stroke(px))
        }

        // the voice ring: bars that grow with how loud you are
        val bars = 64
        for (i in 0 until bars) {
            val a = (i * 2 * PI / bars).toFloat() + spin * 0.3f
            val wobble = 0.5f + 0.5f * sin(i * 0.7f + t * 6f)
            val len = 2f * px + (if (on) amp.coerceIn(0f, 1f) * R * 0.16f * wobble else 0f)
            val r1 = R * 0.40f
            drawLine(
                second.copy(alpha = 0.75f * dim),
                Offset(c.x + cos(a) * r1, c.y + sin(a) * r1),
                Offset(c.x + cos(a) * (r1 + len), c.y + sin(a) * (r1 + len)),
                strokeWidth = 2f * px, cap = StrokeCap.Round
            )
        }

        // the arc reactor in the middle
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.45f * dim), Color.Transparent), c, R * 0.34f), R * 0.34f, c)
        for (i in 0 until 10) {
            arc(c, R * 0.25f, -spin * 12f + i * 36f, 24f, accent.copy(alpha = 0.85f * dim), 6f * px)
        }
        drawCircle(Paper, R * 0.17f, c)
        drawCircle(accent.copy(alpha = 0.9f * dim), R * 0.17f, c, style = Stroke(2f * px))
        val breathe = 0.6f + 0.4f * sin(t * 2.2f)
        drawCircle(accent.copy(alpha = (0.35f + 0.4f * breathe) * dim), R * 0.07f, c)

        // a ripple when it wakes, finishes or hits a problem
        val since = t - pulseAt
        if (since in 0f..1.2f) {
            val p = since / 1.2f
            drawCircle(accent.copy(alpha = 0.7f * (1f - p)), R * (0.3f + 0.7f * p), c, style = Stroke(3f * px * (1f - p) + px))
        }
    }
}

private fun Float.dp2px(d: DrawScope): Float = this * d.density

private fun DrawScope.arc(c: Offset, r: Float, start: Float, sweep: Float, color: Color, width: Float) {
    drawArc(
        color, start, sweep, false,
        topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
        style = Stroke(width, cap = StrokeCap.Round)
    )
}
